import type { LayerRef } from "circuit-json"
import type { ReactElement } from "react"
import { z } from "zod"
import { type AutocompleteString } from "./autocomplete"
import type { KicadAutocompleteStringPath } from "../generated/kicad-autocomplete"
import type { JlcpcbAutocompleteStringPath } from "../generated/jlcpcb-autocomplete"
import type { FootprinterStringExample } from "../generated/footprinter-autocomplete"

/**
 * This is an abbreviated definition of the soup elements that you can find here:
 * https://docs.tscircuit.com/api-reference/advanced/soup#pcb-smtpad
 */
export type FootprintSoupElements = {
  type: "pcb_smtpad" | "pcb_plated_hole"
  x: string | number
  y: string | number
  layer?: LayerRef
  holeDiameter?: string | number
  outerDiameter?: string | number
  shape?: "circle" | "rect"
  width?: string | number
  height?: string | number
  portHints?: string[]
}

export type BasicFootprint =
  | "0402"
  | "0603"
  | "0805"
  | "1206"
  | "1210"
  | "dip"
  | "axial"
  | "soic"
  | "bga"
  | "tssop"
  | "stampboard"
  | "stampreceiver"
  | "hc49"
  | "to92"
  | "to220"
  | "ssop"
  | "qfp"
  | "qfn"
  | "sot23"
  | "sot23_5"
  | "sot223"
  | "pinrow"

type FootprinterStringAutocomplete = BasicFootprint | FootprinterStringExample

export type FootprintProp =
  | AutocompleteString<FootprinterStringAutocomplete>
  | KicadAutocompleteStringPath
  | JlcpcbAutocompleteStringPath
  | ReactElement
  | FootprintSoupElements[]

export const footprintProp = z.custom<FootprintProp>((v) => true)
