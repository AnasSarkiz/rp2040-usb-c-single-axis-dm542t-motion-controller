import { z } from "zod"
import type { AnyCircuitElement, PcbBoard } from "circuit-json"
import type { BoardProps } from "./components/board"
import type { AutocompleteString } from "./common/autocomplete"
import { type CadModelProp, cadModelProp } from "./common/cadModel"
import { type PcbStyle, pcbStyle } from "./common/pcbStyle"
import { url } from "./common/url"
import {
  type AutorouterProp,
  type PartsEngine,
  autorouterProp,
  partsEngine,
} from "./components/group"
import { expectTypesMatch } from "./typecheck"

export interface FootprintLibraryResult {
  footprintCircuitJson: any[]
  cadModel?: CadModelProp
}

export interface FootprintFileParserEntry {
  loadFromUrl: (url: string) => Promise<FootprintLibraryResult>
}

export type CircuitJson = any[]

export interface SpiceEngineSimulationResult {
  engineVersionString?: string
  simulationResultCircuitJson: CircuitJson
}

export interface SpiceEngine {
  simulate: (spiceString: string) => Promise<SpiceEngineSimulationResult>
}

export type SimpleRouteJson = any

export interface AutorouterInstance {
  run: () => Promise<void>
  getOutputSimpleRouteJson: () => Promise<SimpleRouteJson>
}

export interface AutorouterDefinition {
  createAutorouter: (
    simpleRouteJson: SimpleRouteJson,
    opts?: Record<string, unknown>,
  ) => AutorouterInstance | Promise<AutorouterInstance>
}

export interface LocalCacheEngine {
  getItem(key: string): string | Promise<string | null> | null
  setItem(key: string, value: string): void | Promise<void>
  removeItem?(key: string): void | Promise<void>
}

/** e.g. "kicad", this is the prefix used to reference libraries in footprinter strings e.g. kicad:Resistor_0402 **/
type FootprintLibraryPrefix = string

/** e.g. "kicad_mod", used to reference file extensions for loaders **/
type FileExtension = string

type FileContent = string | ArrayBufferLike

type EsModuleImportResult = {
  __esModule: true
  default: any
}

export interface PlatformConfig {
  partsEngine?: PartsEngine

  /** Optional fabricator-specific DRC provider. No checks run when omitted. */
  fabricatorEngine?: FabricatorEngine

  autorouter?: AutorouterProp

  autorouterMap?: Record<string, AutorouterDefinition>

  /** Use networked Pipeline9 node solving at effort 1. Omitted or false keeps local routing.
   * Explicit alternative pipelines and effort levels retain their local solver.
   */
  useCloudAutorouter?: boolean

  /**
   * Allows the deprecated sequential_trace and auto_cloud autorouter presets.
   * Defaults to false because these presets are otherwise disabled.
   * This also applies to the sequential-trace and auto-cloud aliases.
   * Platforms should only enable this temporarily while migrating projects.
   * For sequential_trace / sequential-trace, use the default autorouter with
   * <autoroutingphase /> or <fanout /> elements as needed instead.
   */
  allowLegacyAutorouters?: boolean

  /** A localStorage-compatible cache used by render phases and engines. */
  localCacheEngine?: LocalCacheEngine

  /**
   * Analyze rendered and supplier footprints so manufacturing exporters can
   * align their semantic pin 1 orientations.
   */
  enablePartOrientationAnalysis?: boolean

  /**
   * Maximum time, in milliseconds, that an individual PCB pack solver may run.
   * The timeout is checked between solver steps.
   */
  pcbPackSolverTimeoutMs?: number

  registryApiUrl?: string

  cloudAutorouterUrl?: string

  projectName?: string
  projectBaseUrl?: string
  version?: string
  url?: string
  printBoardInformationToSilkscreen?: boolean
  includeBoardFiles?: string[]
  snapshotsDir?: string

  defaultSpiceEngine?: AutocompleteString<"spicey" | "ngspice">

  unitPreference?: "mm" | "in" | "mil"

  pcbDisabled?: boolean
  routingDisabled?: boolean
  schematicDisabled?: boolean
  partsEngineDisabled?: boolean
  /**
   * Disables analog simulation model processing and simulator execution.
   * Defaults to false.
   */
  analogSimulationDisabled?: boolean
  drcChecksDisabled?: boolean
  netlistDrcChecksDisabled?: boolean
  routingDrcChecksDisabled?: boolean
  placementDrcChecksDisabled?: boolean
  pinSpecificationDrcChecksDisabled?: boolean

  spiceEngineMap?: Record<string, SpiceEngine>

  footprintLibraryMap?: Record<
    FootprintLibraryPrefix,
    | ((
        path: string,
        options?: { resolvedPcbStyle?: PcbStyle },
      ) => Promise<FootprintLibraryResult>)
    | Record<
        string,
        | any[]
        | ((
            path: string,
            options?: { resolvedPcbStyle?: PcbStyle },
          ) => Promise<FootprintLibraryResult>)
      >
  >

  footprintFileParserMap?: Record<FileExtension, FootprintFileParserEntry>

  staticFileLoaderMap?: Record<
    FileExtension,
    (fileContent: FileContent) => Promise<EsModuleImportResult>
  >

  resolveProjectStaticFileImportUrl?: (path: string) => Promise<string>
  nodeModulesResolver?: (modulePath: string) => Promise<string | null>
  platformFetch?: typeof fetch
}

const unvalidatedCircuitJson = z.array(z.any()).describe("Circuit JSON")
const footprintLibraryResult = z.object({
  footprintCircuitJson: z.array(z.any()),
  cadModel: cadModelProp.optional(),
})
const pathToCircuitJsonFn = z
  .function()
  .args(z.string())
  .returns(z.promise(footprintLibraryResult))
  .or(
    z
      .function()
      .args(
        z.string(),
        z.object({ resolvedPcbStyle: pcbStyle.optional() }).optional(),
      )
      .returns(z.promise(footprintLibraryResult)),
  )
  .describe("A function that takes a path and returns Circuit JSON")

const footprintFileParserEntry = z.object({
  loadFromUrl: z
    .function()
    .args(z.string())
    .returns(z.promise(footprintLibraryResult))
    .describe(
      "A function that takes a footprint file URL and returns Circuit JSON",
    ),
})

const spiceEngineSimulationResult = z.object({
  engineVersionString: z.string().optional(),
  simulationResultCircuitJson: unvalidatedCircuitJson,
})

const spiceEngineZod = z.object({
  simulate: z
    .function()
    .args(z.string())
    .returns(z.promise(spiceEngineSimulationResult))
    .describe(
      "A function that takes a SPICE string and returns a simulation result",
    ),
})

const defaultSpiceEngine = z.custom<AutocompleteString<"spicey" | "ngspice">>(
  (value) => typeof value === "string",
)

const autorouterInstance = z.object({
  run: z
    .function()
    .args()
    .returns(z.promise(z.unknown()))
    .describe("Run the autorouter"),
  getOutputSimpleRouteJson: z
    .function()
    .args()
    .returns(z.promise(z.any()))
    .describe("Get the resulting SimpleRouteJson"),
})

const autorouterDefinition = z.object({
  createAutorouter: z
    .function()
    .args(z.any(), z.any().optional())
    .returns(z.union([autorouterInstance, z.promise(autorouterInstance)]))
    .describe("Create an autorouter instance"),
})

const platformFetch = z
  .custom<typeof fetch>((value) => typeof value === "function")
  .describe("A fetch-like function to use for platform requests")

const localCacheEngine = z.custom<LocalCacheEngine>(
  (value) =>
    typeof value === "object" &&
    value !== null &&
    "getItem" in value &&
    typeof value.getItem === "function" &&
    "setItem" in value &&
    typeof value.setItem === "function",
)

export interface FabricatorDrcCheckParams {
  /** Board subtree in Circuit JSON world coordinates: +X right, +Y up, +Z above; positions and distances in mm. */
  circuitJson: AnyCircuitElement[]
  fabricatorPreset: NonNullable<BoardProps["fabricatorPreset"]>
  pcbBoardId: PcbBoard["pcb_board_id"]
}

export interface FabricatorEngine {
  /** Return diagnostic records for the selected preset without modifying the input. */
  runDrcChecks: (
    params: FabricatorDrcCheckParams,
  ) => AnyCircuitElement[] | Promise<AnyCircuitElement[]>
}

export const fabricatorEngine = z.custom<FabricatorEngine>(
  (value) =>
    typeof value === "object" &&
    value !== null &&
    "runDrcChecks" in value &&
    typeof value.runDrcChecks === "function",
)

export const platformConfig = z.object({
  partsEngine: partsEngine.optional(),
  fabricatorEngine: fabricatorEngine.optional(),
  autorouter: autorouterProp.optional(),
  autorouterMap: z.record(z.string(), autorouterDefinition).optional(),
  allowLegacyAutorouters: z.boolean().optional(),
  registryApiUrl: url.optional(),
  cloudAutorouterUrl: url.optional(),
  projectName: z.string().optional(),
  projectBaseUrl: url.optional(),
  version: z.string().optional(),
  url: url.optional(),
  printBoardInformationToSilkscreen: z.boolean().optional(),
  includeBoardFiles: z
    .array(z.string())
    .describe(
      'The board files to automatically build with "tsci build", defaults to ["**/*.circuit.tsx"]. Can be an array of files or globs',
    )
    .optional(),
  snapshotsDir: z
    .string()
    .describe(
      'The directory where snapshots are stored for "tsci snapshot", defaults to "tests/__snapshots__"',
    )
    .optional(),
  defaultSpiceEngine: defaultSpiceEngine.optional(),
  unitPreference: z.enum(["mm", "in", "mil"]).optional(),
  localCacheEngine: localCacheEngine.optional(),
  useCloudAutorouter: z.boolean().optional(),
  enablePartOrientationAnalysis: z.boolean().optional(),
  pcbPackSolverTimeoutMs: z.number().finite().positive().optional(),
  pcbDisabled: z.boolean().optional(),
  routingDisabled: z.boolean().optional(),
  schematicDisabled: z.boolean().optional(),
  partsEngineDisabled: z.boolean().optional(),
  analogSimulationDisabled: z.boolean().optional(),
  drcChecksDisabled: z.boolean().optional(),
  netlistDrcChecksDisabled: z.boolean().optional(),
  routingDrcChecksDisabled: z.boolean().optional(),
  placementDrcChecksDisabled: z.boolean().optional(),
  pinSpecificationDrcChecksDisabled: z.boolean().optional(),
  spiceEngineMap: z.record(z.string(), spiceEngineZod).optional(),
  footprintLibraryMap: z
    .record(
      z.string(),
      z.union([
        pathToCircuitJsonFn,
        z.record(
          z.string(),
          z.union([unvalidatedCircuitJson, pathToCircuitJsonFn]),
        ),
      ]),
    )
    .optional(),
  footprintFileParserMap: z
    .record(z.string(), footprintFileParserEntry)
    .optional(),
  resolveProjectStaticFileImportUrl: z
    .function()
    .args(z.string())
    .returns(z.promise(z.string()))
    .describe(
      "A function that returns a string URL for static files for the project",
    )
    .optional(),
  platformFetch: platformFetch.optional(),
}) as z.ZodType<PlatformConfig>

expectTypesMatch<PlatformConfig, z.infer<typeof platformConfig>>(true)
