import { ms, frequency } from "circuit-json"
import {
  type CommonComponentProps,
  commonComponentProps,
} from "lib/common/layout"
import { connectionTarget } from "lib/common/connectionsProp"
import type { SchematicPinLabel } from "lib/common/schematicPinLabel"
import {
  noConnectProp,
  type PinLabelsProp,
  pinLabelsProp,
} from "lib/components/chip"
import type { Connections } from "lib/utility-types/connections-and-selectors"
import { expectTypesMatch } from "lib/typecheck"

import { z } from "zod"

export interface SwitchProps extends CommonComponentProps {
  type?: "spst" | "spdt" | "dpst" | "dpdt"
  pinLabels?: PinLabelsProp<SchematicPinLabel>
  /**
   * Pin names or aliases intentionally left unconnected. Accepts mutable or
   * readonly arrays, using the same label validation as chip noConnect.
   * Omitted or empty arrays mark no pins. Parsed labels are preserved and
   * matching source ports get do_not_connect; explicit connections are not removed.
   */
  noConnect?: readonly SchematicPinLabel[] | SchematicPinLabel[]
  isNormallyClosed?: boolean
  spdt?: boolean
  spst?: boolean
  dpst?: boolean
  dpdt?: boolean
  simSwitchFrequency?: number | string
  simCloseAt?: number | string
  simOpenAt?: number | string
  simStartClosed?: boolean
  simStartOpen?: boolean
  connections?: Connections<string>
}

export const switchProps = commonComponentProps
  .extend({
    type: z.enum(["spst", "spdt", "dpst", "dpdt"]).optional(),
    isNormallyClosed: z.boolean().optional().default(false),
    spst: z.boolean().optional(),
    spdt: z.boolean().optional(),
    dpst: z.boolean().optional(),
    dpdt: z.boolean().optional(),
    pinLabels: pinLabelsProp.optional(),
    noConnect: noConnectProp.optional(),
    simSwitchFrequency: frequency.optional(),
    simCloseAt: ms.optional(),
    simOpenAt: ms.optional(),
    simStartClosed: z.boolean().optional(),
    simStartOpen: z.boolean().optional(),
    connections: z
      .custom<Connections<string>>()
      .pipe(z.record(z.string(), connectionTarget))
      .optional(),
  })
  .transform((props) => {
    const updatedProps: SwitchProps = { ...props }

    if (updatedProps.dpdt) {
      updatedProps.type = "dpdt"
    } else if (updatedProps.spst) {
      updatedProps.type = "spst"
    } else if (updatedProps.spdt) {
      updatedProps.type = "spdt"
    } else if (updatedProps.dpst) {
      updatedProps.type = "dpst"
    }

    switch (updatedProps.type) {
      case "spdt":
        updatedProps.spdt = true
        break
      case "spst":
        updatedProps.spst = true
        break
      case "dpst":
        updatedProps.dpst = true
        break
      case "dpdt":
        updatedProps.dpdt = true
        break
    }

    return updatedProps
  })

export type InferredSwitchProps = z.infer<typeof switchProps>
expectTypesMatch<SwitchProps, InferredSwitchProps>(true)
