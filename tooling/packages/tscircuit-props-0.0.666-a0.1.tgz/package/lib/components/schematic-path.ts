import { distance, point } from "circuit-json"
import { z } from "zod"
import { expectTypesMatch } from "lib/typecheck"
import type { Distance } from "lib/common/distance"
import type { Point } from "lib/common/point"

export const schematicPathProps = z.object({
  points: z.array(point).optional(),
  svgPath: z.string().optional(),
  strokeWidth: distance.optional(),
  strokeColor: z.string().optional(),
  dashLength: distance.optional(),
  dashGap: distance.optional(),
  isFilled: z.boolean().optional().default(false),
  fillColor: z.string().optional(),
})

export interface SchematicPathProps {
  points?: Point[]
  svgPath?: string
  strokeWidth?: Distance
  strokeColor?: string
  dashLength?: Distance
  dashGap?: Distance
  isFilled?: boolean
  fillColor?: string
}

export type InferredSchematicPathProps = z.input<typeof schematicPathProps>

expectTypesMatch<SchematicPathProps, z.input<typeof schematicPathProps>>(true)
